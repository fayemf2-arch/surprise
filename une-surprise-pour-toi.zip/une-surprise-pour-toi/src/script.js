// SÉLECTION DES ÉLÉMENTS
const page1 = document.getElementById('page1');
const page2 = document.getElementById('page2');
const btnNext = document.getElementById('btn-next');
const btnOui = document.getElementById('btn-oui');
const btnNon = document.getElementById('btn-non');
const messageFinal = document.getElementById('message-final');

// ÉTAPE 1 : ALLER À LA PAGE 2
btnNext.addEventListener('click', () => {
  page1.classList.remove('visible');
  page1.classList.add('hidden');
  page2.classList.remove('hidden');
  page2.classList.add('visible');
});

// ÉTAPE 2 : LA QUESTION - GESTION DES BOUTONS OUI ET NON

// 1. Quand elle clique sur "OUI"
btnOui.addEventListener('click', () => {
  btnOui.style.display = 'none'; // On cache le bouton Oui
  btnNon.style.display = 'none'; // On cache le bouton Non
  messageFinal.classList.remove('hidden'); // On montre le message d'amour final
  document.body.style.backgroundColor = '#f8bbd0'; // On rend le fond encore plus rose
});

// 2. Quand elle clique sur "non" (le petit jeu)
btnNon.addEventListener('mouseover', () => {
  // Le bouton "non" s'enfuit quand on le survol ! C'est le petit jeu.
  const randomX = Math.random() * 200 - 100; // Un déplacement aléatoire en X
  const randomY = Math.random() * 100 - 50; // Un déplacement aléatoire en Y
  btnNon.style.transform = `translate(${randomX}px, ${randomY}px)`;
});

btnNon.addEventListener('click', () => {
  // Au cas où elle arriverait à cliquer sur le non !
  alert('Haha, essaye encore ! Le non est interdit. ;)');
  btnNon.style.transform = `translate(0, 0)`; // On le remet à sa place
});